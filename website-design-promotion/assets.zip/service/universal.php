<?php

class universal {
    
    function params() {
        
            $landing = "custom-logo-design";

            $parameters = array (
                "url" => "https://".$_SERVER['HTTP_HOST']."/",
            );
    
            return ($parameters);
        
        
        
        
    }

}

?>