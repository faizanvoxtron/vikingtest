<?php

class universal {
    
    function params() {
        
            $landing = "web-offer";

            $parameters = array (
                "url" => "https://".$_SERVER['HTTP_HOST']."/",
            );
    
            return ($parameters);
        
        
        
        
    }

}

?>