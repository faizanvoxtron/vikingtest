<?php

class universal {
    
    function params() {
        
            $landing = "logo-promotion";

            $parameters = array (
                "url" => "https://".$_SERVER['HTTP_HOST']."/",
            );
    
            return ($parameters);
        
        
        
        
    }

}

?>